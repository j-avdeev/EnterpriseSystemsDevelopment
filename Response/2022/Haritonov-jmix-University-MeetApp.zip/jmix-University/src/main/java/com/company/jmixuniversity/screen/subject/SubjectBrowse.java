package com.company.jmixuniversity.screen.subject;

import io.jmix.ui.screen.*;
import com.company.jmixuniversity.entity.Subject;

@UiController("Subject.browse")
@UiDescriptor("subject-browse.xml")
@LookupComponent("subjectsTable")
public class SubjectBrowse extends StandardLookup<Subject> {
}