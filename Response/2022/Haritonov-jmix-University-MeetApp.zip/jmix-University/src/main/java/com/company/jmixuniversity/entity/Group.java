package com.company.jmixuniversity.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.UUID;

@JmixEntity
@Table(name = "GROUP_")
@Entity(name = "Group_")
public class Group {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "STUDY_YEAR")
    @NotNull
    private Integer studyYear;

    @InstanceName
    @Column(name = "NUMBER_", unique = true)
    private String number;

    @OneToMany(mappedBy = "group")
    private List<Student> students;

    @OneToMany(mappedBy = "group")
    private List<Course> courses;

    @JoinTable(name = "ONLINE_MEETING_GROUP_LINK",
            joinColumns = @JoinColumn(name = "GROUP_ID", referencedColumnName = "ID"),
            inverseJoinColumns = @JoinColumn(name = "ONLINE_MEETING_ID", referencedColumnName = "ID"))
    @ManyToMany
    private List<OnlineMeeting> onlineMeetings;

    public List<OnlineMeeting> getOnlineMeetings() {
        return onlineMeetings;
    }

    public void setOnlineMeetings(List<OnlineMeeting> onlineMeetings) {
        this.onlineMeetings = onlineMeetings;
    }

    public StudyYear getStudyYear() {
        return studyYear == null ? null : StudyYear.fromId(studyYear);
    }

    public void setStudyYear(StudyYear studyYear) {
        this.studyYear = studyYear == null ? null : studyYear.getId();
    }

    public List<Course> getCourses() {
        return courses;
    }

    public void setCourses(List<Course> courses) {
        this.courses = courses;
    }

    public List<Student> getStudents() {
        return students;
    }

    public void setStudents(List<Student> students) {
        this.students = students;
    }

    public String  getNumber() {
        return number;
    }

    public void setNumber(String  number) {
        this.number = number;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}