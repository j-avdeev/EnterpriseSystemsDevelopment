package com.company.jmixuniversity.screen.subject;

import io.jmix.ui.screen.*;
import com.company.jmixuniversity.entity.Subject;

@UiController("Subject.edit")
@UiDescriptor("subject-edit.xml")
@EditedEntityContainer("subjectDc")
public class SubjectEdit extends StandardEditor<Subject> {
}