package com.company.jmixuniversity.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum StudyYear implements EnumClass<Integer> {

    _1(1),
    _2(2),
    _3(3),
    _4(4);

    private Integer id;

    StudyYear(Integer value) {
        this.id = value;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static StudyYear fromId(Integer id) {
        for (StudyYear at : StudyYear.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}