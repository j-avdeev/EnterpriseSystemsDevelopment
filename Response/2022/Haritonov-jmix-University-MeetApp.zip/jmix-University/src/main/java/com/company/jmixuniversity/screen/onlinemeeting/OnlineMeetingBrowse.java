package com.company.jmixuniversity.screen.onlinemeeting;

import com.company.jmixuniversity.entity.OnlineMeeting;
import io.jmix.core.DataManager;
import io.jmix.core.LoadContext;
import io.jmix.core.security.CurrentAuthentication;
import io.jmix.ui.screen.*;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@UiController("OnlineMeeting.browse")
@UiDescriptor("online-meeting-browse.xml")
@LookupComponent("onlineMeetingsTable")
public class OnlineMeetingBrowse extends StandardLookup<OnlineMeeting> {
    @Autowired
    private DataManager dataManager;
    @Autowired
    private CurrentAuthentication currentAuthentication;

    @Install(to = "onlineMeetingsDl", target = Target.DATA_LOADER)
    private List<OnlineMeeting> onlineMeetingsDlLoadDelegate(LoadContext<OnlineMeeting> loadContext) {
        String username = currentAuthentication.getUser().getUsername();
        if (!username.equals("admin")) {
             List<OnlineMeeting> onlineMeetings = dataManager.load(OnlineMeeting.class)
                    .query("select om from OnlineMeeting om " +
                            "join om.groups g " +
                            "where g.id in (select g.id from Group_ g join g.students s where s.username= :username)")
                    .parameter("username", username)
                    .list();
            onlineMeetings.addAll(dataManager.load(OnlineMeeting.class)
                    .query("select om from OnlineMeeting om " +
                            "join Student s on om.course.group.id = s.group.id " +
                            "where s.username = :username")
                    .parameter("username", username)
                    .list());
            onlineMeetings.addAll(dataManager.load(OnlineMeeting.class)
                    .query("select om from OnlineMeeting om " +
                            "where om.organizer.username = :username")
                    .parameter("username", username)
                    .list());
            onlineMeetings.addAll(dataManager.load(OnlineMeeting.class)
                    .query("select om from OnlineMeeting om " +
                            "join om.teachers t " +
                            "where t.username = :username ")
                    .parameter("username", username)
                    .list());
            return onlineMeetings;
        }
        return dataManager.loadList(loadContext);
    }
}