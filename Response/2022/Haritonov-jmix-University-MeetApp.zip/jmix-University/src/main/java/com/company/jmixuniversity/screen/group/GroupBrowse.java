package com.company.jmixuniversity.screen.group;

import io.jmix.core.DataManager;
import io.jmix.core.LoadContext;
import io.jmix.ui.screen.*;
import com.company.jmixuniversity.entity.Group;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@UiController("Group_.browse")
@UiDescriptor("group-browse.xml")
@LookupComponent("groupsTable")
public class GroupBrowse extends StandardLookup<Group> {
    private List<String> groupNumbers;
    @Autowired
    private DataManager dataManager;

    public List<String> getGroupNumbers() {
        return groupNumbers;
    }

    public void setGroupNumbers(List<String> groupNumbers) {
        this.groupNumbers = groupNumbers;
    }

    @Install(to = "groupsDl", target = Target.DATA_LOADER)
    private List<Group> groupsDlLoadDelegate(LoadContext<Group> loadContext) {
        if (groupNumbers != null) {
            return dataManager.load(Group.class)
                    .query("select g from Group_ g where g.number not in :groupNumbers")
                    .parameter("groupNumbers", groupNumbers)
                    .list();
        }
        return dataManager.loadList(loadContext);
    }


}