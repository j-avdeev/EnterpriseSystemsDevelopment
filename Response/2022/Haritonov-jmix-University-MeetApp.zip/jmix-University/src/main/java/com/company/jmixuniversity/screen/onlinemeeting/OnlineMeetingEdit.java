package com.company.jmixuniversity.screen.onlinemeeting;

import com.company.jmixuniversity.entity.*;
import com.company.jmixuniversity.screen.course.CourseBrowse;
import com.company.jmixuniversity.screen.group.GroupBrowse;
import com.company.jmixuniversity.screen.teacher.TeacherBrowse;
import io.jmix.core.DataManager;
import io.jmix.core.security.CurrentAuthentication;
import io.jmix.ui.action.list.AddAction;
import io.jmix.ui.component.*;
import io.jmix.ui.component.data.TableItems;
import io.jmix.ui.model.CollectionPropertyContainer;
import io.jmix.ui.screen.*;
import org.springframework.beans.factory.annotation.Autowired;

import javax.inject.Named;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

@UiController("OnlineMeeting.edit")
@UiDescriptor("online-meeting-edit.xml")
@EditedEntityContainer("onlineMeetingDc")
public class OnlineMeetingEdit extends StandardEditor<OnlineMeeting> {
    @Autowired
    private DataManager dataManager;
    @Autowired
    private CurrentAuthentication currentAuthentication;
    @Autowired
    private EntityPicker<User> organizerField;
    @Autowired
    private TextField<String> nameField;
    @Autowired
    private DateField<LocalDateTime> startField;
    @Autowired
    private EntityPicker<Course> courseField;
    @Autowired
    private Table<Group> groupsTable;
    @Autowired
    private CollectionPropertyContainer<Group> groupsDc;
    private List<Group> selectedGroups;
    @Named("groupsTable.add")
    private AddAction<Group> groupsTableAdd;
    @Autowired
    private Table<Teacher> teachersTable;

    @Subscribe
    public void onInitEntity(InitEntityEvent<OnlineMeeting> event) {
        String currentUserUsername = currentAuthentication.getUser().getUsername();
        User organizer = dataManager.load(User.class)
                        .query("select t from User t where t.username = :username")
                                .parameter("username", currentUserUsername)
                .optional().orElse(null);
        if (organizer != null) {
            event.getEntity().setOrganizer(organizer);
            organizerField.setEditable(false);
        }
    }

    @Subscribe("courseField")
    public void onCourseFieldValueChange(HasValue.ValueChangeEvent<Course> event) {
        Course course = event.getValue();
        updateNameFieldValue(event.getValue(), startField.getValue());
        if (course != null) {
            selectedGroups = groupsDc.getItems();
            groupsDc.setItems(new LinkedList<>());
            groupsTableAdd.setEnabled(false);
        }
        else {
            if (selectedGroups != null) {
                groupsDc.setItems(selectedGroups);
            }
            groupsTableAdd.setEnabled(true);
        }
    }

    @Subscribe("startField")
    public void onStartFieldValueChange(HasValue.ValueChangeEvent<LocalDateTime> event) {
        if (courseField.getValue() != null) {
            updateNameFieldValue(courseField.getValue(), event.getValue());
        }
    }

    private void updateNameFieldValue(Course course, LocalDateTime start) {
        String nameFieldValue = "";
        if (course != null) {
            nameFieldValue += course.getInstanceName();
            if (start != null) {
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
                nameFieldValue += ", " + start.format(formatter);
            }
        }
        nameField.setValue(nameFieldValue);
    }

    @Install(to = "courseField.entityLookup", subject = "screenConfigurer")
    private void courseFieldEntityLookupScreenConfigurer(Screen screen) {
        String currentUserUsername = currentAuthentication.getUser().getUsername();
        ((CourseBrowse) screen).setTeacherUsername(currentUserUsername);
    }

    @Install(to = "groupsTable.add", subject = "screenConfigurer")
    private void groupsTableAddScreenConfigurer(Screen screen) {
        TableItems<Group> groupTableItems = groupsTable.getItems();
        if (groupTableItems != null) {
            List<String> groupNumbers = groupTableItems.getItems().stream().map(Group::getNumber).collect(Collectors.toList());
            Course course = courseField.getValue();
            if (course != null) {
                Group group = dataManager.load(Group.class)
                        .query("select g from Group_ g join g.courses c where c.id = :courseId")
                        .parameter("courseId", course.getId())
                        .one();
                groupNumbers.add(group.getNumber());
            }
            ((GroupBrowse) screen).setGroupNumbers(groupNumbers);
        }
    }

    @Install(to = "teachersTable.add", subject = "screenConfigurer")
    private void teachersTableAddScreenConfigurer(Screen screen) {
        TableItems<Teacher> groupTableItems = teachersTable.getItems();
        if (groupTableItems != null) {
            List<Teacher> teachers = new ArrayList<>(groupTableItems.getItems());
            String currentUserUsername = currentAuthentication.getUser().getUsername();
            Teacher organizer = dataManager.load(Teacher.class)
                    .query("select t from Teacher t where t.username = :username")
                    .parameter("username", currentUserUsername)
                    .optional().orElse(null);
            teachers.add(organizer);
            ((TeacherBrowse) screen).setTeachers(teachers);
        }
    }
}