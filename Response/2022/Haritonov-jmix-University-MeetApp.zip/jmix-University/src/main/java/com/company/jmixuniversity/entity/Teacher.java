package com.company.jmixuniversity.entity;

import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.*;
import java.util.List;

@JmixEntity
@Entity
public class Teacher extends User {
    @OneToMany(mappedBy = "teacher")
    private List<Course> courses;

    @JoinTable(name = "ONLINE_MEETING_TEACHER_LINK",
            joinColumns = @JoinColumn(name = "TEACHER_ID", referencedColumnName = "ID"),
            inverseJoinColumns = @JoinColumn(name = "ONLINE_MEETING_ID", referencedColumnName = "ID"))
    @ManyToMany
    private List<OnlineMeeting> onlineMeetings;

    public List<OnlineMeeting> getOnlineMeetings() {
        return onlineMeetings;
    }

    public void setOnlineMeetings(List<OnlineMeeting> onlineMeetings) {
        this.onlineMeetings = onlineMeetings;
    }

    public List<Course> getCourses() {
        return courses;
    }

    public void setCourses(List<Course> courses) {
        this.courses = courses;
    }

    @InstanceName
    @DependsOnProperties({"lastName", "firstName", "middleName"})
    public String getInstanceName() {
        return String.format("%s %s %s", getLastName(), getFirstName(), getMiddleName());
    }
}