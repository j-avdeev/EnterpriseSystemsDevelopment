package com.company.jmixuniversity.screen.teacher;

import io.jmix.core.DataManager;
import io.jmix.core.LoadContext;
import io.jmix.ui.screen.*;
import com.company.jmixuniversity.entity.Teacher;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.stream.Collectors;

@UiController("Teacher.browse")
@UiDescriptor("teacher-browse.xml")
@LookupComponent("teachersTable")
public class TeacherBrowse extends StandardLookup<Teacher> {
    private List<Teacher> teachers;
    @Autowired
    private DataManager dataManager;

    public List<Teacher> getTeachers() {
        return teachers;
    }

    public void setTeachers(List<Teacher> teachers) {
        this.teachers = teachers;
    }

    @Install(to = "teachersDl", target = Target.DATA_LOADER)
    private List<Teacher> teachersDlLoadDelegate(LoadContext<Teacher> loadContext) {
        if (teachers != null) {
            return dataManager.loadList(loadContext).stream().filter(teacher -> !teachers.contains(teacher)).collect(Collectors.toList());
        }
        return dataManager.loadList(loadContext);
    }
}