package com.company.jmixuniversity.screen.course;

import io.jmix.core.DataManager;
import io.jmix.core.LoadContext;
import io.jmix.ui.screen.*;
import com.company.jmixuniversity.entity.Course;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@UiController("Course.browse")
@UiDescriptor("course-browse.xml")
@LookupComponent("coursesTable")
public class CourseBrowse extends StandardLookup<Course> {
    private String teacherUsername;
    @Autowired
    private DataManager dataManager;

    public String getTeacherUsername() {
        return teacherUsername;
    }

    public void setTeacherUsername(String teacherUsername) {
        this.teacherUsername = teacherUsername;
    }

    @Install(to = "coursesDl", target = Target.DATA_LOADER)
    private List<Course> coursesDlLoadDelegate(LoadContext<Course> loadContext) {
        if (teacherUsername != null) {
            return dataManager.load(Course.class)
                    .query("select c from Course c where c.teacher.username=:teacher_username")
                    .parameter("teacher_username", teacherUsername)
                    .list();
        }
        return dataManager.loadList(loadContext);
    }
}