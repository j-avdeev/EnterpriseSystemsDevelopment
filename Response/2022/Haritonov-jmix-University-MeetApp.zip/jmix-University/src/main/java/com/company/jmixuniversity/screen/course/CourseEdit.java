package com.company.jmixuniversity.screen.course;

import io.jmix.ui.screen.*;
import com.company.jmixuniversity.entity.Course;

@UiController("Course.edit")
@UiDescriptor("course-edit.xml")
@EditedEntityContainer("courseDc")
public class CourseEdit extends StandardEditor<Course> {
}