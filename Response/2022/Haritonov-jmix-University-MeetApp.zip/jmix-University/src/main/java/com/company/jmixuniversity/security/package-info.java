@NonNullApi
package com.company.jmixuniversity.security;

import org.springframework.lang.NonNullApi;