package com.company.jmixuniversity.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@JmixEntity
@Table(name = "ONLINE_MEETING", indexes = {
        @Index(name = "IDX_ONLINEMEETING", columnList = "ORGANIZER_ID"),
        @Index(name = "IDX_ONLINEMEETING_COURSE_ID", columnList = "COURSE_ID")
})
@Entity
public class OnlineMeeting {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @JoinColumn(name = "ORGANIZER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private User organizer;

    @JoinColumn(name = "COURSE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Course course;

    @InstanceName
    @Column(name = "NAME")
    private String name;

    @Column(name = "START_")
    private LocalDateTime start;

    @Column(name = "LINK")
    private String link;

    @JoinTable(name = "ONLINE_MEETING_GROUP_LINK",
            joinColumns = @JoinColumn(name = "ONLINE_MEETING_ID", referencedColumnName = "ID"),
            inverseJoinColumns = @JoinColumn(name = "GROUP_ID", referencedColumnName = "ID"))
    @ManyToMany
    private List<Group> groups;

    @JoinTable(name = "ONLINE_MEETING_TEACHER_LINK",
            joinColumns = @JoinColumn(name = "ONLINE_MEETING_ID", referencedColumnName = "ID"),
            inverseJoinColumns = @JoinColumn(name = "TEACHER_ID", referencedColumnName = "ID"))
    @ManyToMany
    private List<Teacher> teachers;

    public void setOrganizer(User organizer) {
        this.organizer = organizer;
    }

    public User getOrganizer() {
        return organizer;
    }

    public List<Teacher> getTeachers() {
        return teachers;
    }

    public void setTeachers(List<Teacher> teachers) {
        this.teachers = teachers;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }

    public List<Group> getGroups() {
        return groups;
    }

    public void setGroups(List<Group> groups) {
        this.groups = groups;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public LocalDateTime getStart() {
        return start;
    }

    public void setStart(LocalDateTime start) {
        this.start = start;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}