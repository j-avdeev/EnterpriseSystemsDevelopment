alter table TEACHINGSTUDENTS_STUDENT drop column GROUP___U58834 cascade ;
