alter table HOTELRESERVE_BOOKING add column STATE varchar(255) ;
